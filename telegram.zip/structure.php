<?php

/**
 * Class Structure 
 * 
 * Cette classe est la classe mère de toutes les entités - pharmacie, etc. 
 * 
 * @author Samgolchi<mawusee.foli@gmail.com>
 * @copyright Copyright (c) 2017
 */
//TODO
//- Integrer Tentite :-)
//- Integrer namespace
 
//namespace Telegram;

class Structure
{
    /** @var db */
    public $db;
    /** @var string */
    public $type='AUTRE';
    /** @var int */
    private $chat_id;
    
    var $table_prefix = 'zbot_tg';
    var $table = 'structure';
    var $champs = '';

    /**
     * structure constructor
     * @param db $db
     * @param $chat_id
     */
    public function __construct($db, $chat_id)
    {               
        $this->db = $db;
        $this->chat_id = intval($chat_id);        
    }

    /**
     * Retourne la liste de toutes les structures
     * @return bool|db_result
     */
    public function annuaire()
    {
        $query = "SELECT * FROM ".$this->table_prefix."_".$this->table." WHERE type='".$this->type."'";
        //return $this->db->query($query)->fetch_all();
        $result =  $this->db->query($query);        
        $liste = "";
        $k = 1;
        while($row = $result->fetchArray(SQLITE3_ASSOC) ){
            $liste .= urlencode("\n".$k."- PHARMACIE ".substr($row['nom'],10));
            $k++;
        }        
        $liste =  utf8_encode($liste);
        return $liste;
    }

    /**
     * Recherche les structures d'un lieu (quartier, ville, region)
     * @return bool|db_result
     */
    public function annuaire_Lieu($id_lieu, $type_lieu)
    {
        $query = "SELECT * FROM  ".$this->table_prefix."_".$this->table." 
        INNER JOIN 
        WHERE (type='".$this->type."')";
        return $this->db->query($query)->fetch_all();
    }

    /**
     * Recherche une structure a partie de son nom
     * @return string
     */
    public function recherche($nom_recherche)
    {
        $query = "SELECT * FROM  ".$this->table_prefix."_".$this->table."  WHERE (nom LIKE '%$nom_recherche%') AND (type='".$this->type."')";
		return $this->db->query($query)->fetch_all();     
    }

    /**
     * Ajouter une structure
     * @return string
     */
    public function ajouter($details, $separateur='**', $type='AUTRE')
    {
        $nom = $description = $quartier = '';
        $id_quartier = //TODO get id
        list($nom, $quartier, $description) = explode('**', $details);
        var_dump($nom, $quartier, $description, $type, $details);
        $query = 'INSERT INTO '.$this->table_prefix.'_'.$this->table.' (id, nom, description, type, adresse, id_quartier, id_region) 
                    VALUES (168, "'.$nom.'", "'.$description.'", "'.$this->type.'", "lomé",  "10", "2")';
                    echo $query;
		$res = $this->db->query($query);
        var_dump($res, $this->db); 
        return $res;     
    }
	
	

}