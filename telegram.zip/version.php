<?php
// Ce fichier aura la valeur de la version du code/projet pour suivre les diff�rentes versions
?>