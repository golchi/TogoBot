<?php
/* Copyright (C) 2017 Samgolchi  <mawusee.foli@gmail.com>
 *
 */

/**
 *	\file       index.php
 *	\ingroup    telegram
 *	\brief      Gere les commandes et I/O
 */
/**
* Format des messages a prendre en compte
* Texte : command # text...
* Image
* Audio
* Video
* 
* Les lignes "file_get_contents ($website."/sendmessage?chat_id=".$chatId."&text=Debug-$text")" servent à débugger; cette ligne envoie le message voulu
* dans le chat de l'utilisateur.
* $website : le chemin du webhook (chemin api concatene au token)
* $chatId  : le numero ID du chat de l'utilisateur - un chat par utilisateur/conversation
* $text    : le message qui sera affiché
* 
*/
  
//TODO: Utilisez le concept de namespace pour harmonisation
//namespace Telegram;

$token   = "xxx:xxx-k"; //Bot token
$website = "https://api.telegram.org/bot".$token;

//TODO : Utiliser le fichier config
require_once 'mydb.php';
require_once 'log.php';
require_once 'pharmacie.php';
require_once 'suggestion.php';

define('LOG_FILE_PATH','error_log');
//La base de donnees sqlite
define('SQLITE_DB','db/toutazimut.db');
//Mode de debogage - en local c'est utile
define('DEBUG',0);
define('LOCALHOST',1);

//Cette constante definie quel SGBD a prendre en compte
//define('SGBD','MYSQLI');
define('SGBD','SQLITE');

$localhost = 1;
$debug = 1;
$update_str = "";
$command = '';
$text = '';

/**
*/
try {
    if ($localhost == 0) {        
        if ($debug == 0) {
			//En ligne on récupère les inputs de l'utilisateur
			$update  = file_get_contents('php://input');
            $updateArray = json_decode($update, TRUE);
        } else {	
			// En local on récupère les inputs de l'utilisateur depuis le chat par le lien
            $update  = file_get_contents($website."/getupdates");
            $updateArray = json_decode($update, TRUE);
            $dernier_msg = count($updateArray["result"]);
            $updateArray = $updateArray["result"][$dernier_msg-1];
        }
        $chatId = $updateArray["message"]["chat"]["id"];
        $text = $updateArray["message"]["text"];        
        $update_str = serialize($updateArray);
    } else {
        $text = 'p-ajout#My DADDDA**AGOE**Donec ut est in lectus consequat consequat. Etiam eget dui. Aliquam erat volutpat. Sed at lorem in nunc porta tristique. Proin nec augue. Quisque aliquam tempor magna. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nunc ac magna. Maecenas odio dolor, vulputate vel, auctor ac, accumsan id, felis. Pellentesque cursus sagittis felis.';
        $text = 'suggestion';
        $chatId = 1;
    }
    $tab_text = explode('#',$text);
    if(count($tab_text)>1){ $command = $tab_text[0]; $text = $tab_text[1]; } else $command = $text;
    $command = strtolower($command);    
    //var_dump($tab_text,$text, $command);
    
    //Send a reply
    //file_get_contents($website."/sendmessage?chat_id=".$chatId."&text=Debug-$text");

    // connect to database
    if(SGBD == 'MYSQLI') {
        $config = require 'config.php';
        $db = new mysqli($config['database_host'], $config['database_user'], $config['database_password'], $config['database_name']);        
    }
    elseif(SGBD == 'SQLITE'){
        //require 'sqlite.php';                
        $db = new MyDB(SQLITE_DB);
    }       
            
    $t = $command.'--'.$update_str;
    $log = new Log($db, $chatId);
    $log->logMessage($chatId, $t, 'Sam');
    
    //Send a reply
    //$m = "Apres texte avant db connexion";
    //file_get_contents($website."/sendmessage?chat_id=".$chatId."&text=$m");

    // create keyboards collection
    $keyboard =  [['Demarrer', 'Pharmacies', 'Garde'], ['Pharmacies', 'Feedback']];

    $reply_kb_markup = [
        'keyboard' => $keyboard, 
        'resize_keyboard' => true, 
        'one_time_keyboard' => true
    ];
    $reply_kb_markup_json = json_encode($reply_kb_markup);


    //Send a reply
    //$m = "Apres texte avant traitement requete";
    //file_get_contents($website."/sendmessage?chat_id=".$chatId."&text=$m");

    //Check command
    switch($command){
        case 'demarrer':
        case '/start':
            $message = "Actuellement je peux vous informer sur les pharmacies.";
            break;
        //Menus des pharmacies    
        case 'garde':
        case 'p-garde':
        case '/garde':            
            $pharmacie = new Pharmacie($db, $chatId);
            //$tab_message = "Les pharmacies de garde ";
            $tab_message = $pharmacie->garde();

            //Send a reply
            $message = $tab_message;
            //$m = "apres traitement requete garde";
            //file_get_contents($website."/sendmessage?chat_id=".$chatId."&text=$message");
            //$message = json_encode($tab_message);
            break;
        case 'p-recherche':
        case '/p-recherche':
            $pharmacie = new Pharmacie($db, $chatId);
            $message = "Saisir une partie du nom de la pharmacie";
            
            break;
        case 'p-annuaire':
        case 'pharmacies':
        case '/pharmacies':
            $pharmacie = new Pharmacie($db, $chatId);
            $tab_message []= "L'annuaire des pharmacie est ici";
            $tab_message []= json_encode($pharmacie->annuaire());   
            $message = $pharmacie->annuaire();       
            break;
        case 'p-ajout':
        case 'p-nouveau':
        case '/p-ajout':
            $pharmacie = new Pharmacie($db, $chatId);
            $message = $pharmacie->ajouter($text);       
            //$tab_message []= "L'annuaire des pharmacie est ici";
            //$tab_message []= json_encode($message);   
            break;
            
        //Menu Admin
        
        //Menu Suggestion
        case 's-ajouter':
        case 'suggestion':
        //case '':
            $suggestion = new Suggestion($db, $chatId);
            $tab_message []= "La liste des suggestions est ici";
            $tab_message []= json_encode($suggestion->liste());   
            $message = $suggestion->liste();       
            break;
        case 'log':
        case '/log':
            //if ($username == 'samgolchi')
            $message = $log->liste(); //"Stats des messages recus";
            
            break;        
        default :
            $message = "Je veux bien t'aider mais ... je ne peux";
            
            break;
    }
    if (($localhost == 1 ) && ($debug == 1)){ 
        echo ($message);          
        var_dump($message);
    }        
    //Send a reply
    file_get_contents($website."/sendmessage?chat_id=".$chatId."&text=$message&reply_markup=$reply_kb_markup_json");
    
    //$message2 = 'Apres retour liste';
    //file_get_contents($website."/sendmessage?chat_id=".$chatId."&text=$message2");
            

} catch (\Exception $e) {
	//Log errors to a file - Creation d'un fichier de Log des erreurs
	$log_file = fopen(LOG_FILE_PATH,"a+");		
	$time = date("d/m/Y - H:i:s");
	$error_message = $time .'- Message: '.$e->getMessage().$config['database_user'];
	fwrite($log_file, $error_message);
	fwrite($log_file,"\n");
	fclose($log_file);
	
}
?>	