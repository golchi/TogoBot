<?php
/**
 *  Ce fichier concerne toutes les fonctions utiles à un bot
 */
 
//namespace Telegram;

class Log 
{
    /** @var string */
    public $type;
    /** @var int */
    private $chat_id;
    
    public $db;
    var $table_prefix = 'zbot_tg';
    var $table = 'log';
    //var $champs = '';

    /**
     * structure constructor
     * @param db $db
     * @param $chat_id
     */
    public function __construct($db, $chat_id)
    {               
        $this->db = $db;
        $this->chat_id = intval($chat_id);        
    }
    
    /**
     *  Cette fonction permet de stocker toutes les demandes envoyées au bot
     */
    function logMessage($chatId='', $msg='', $username='') {
        $current_date = date('Y-m-d H:i:s');
        $query = 'INSERT INTO  '.$this->table_prefix.'_'.$this->table.' (msg, chatid, username, datetime) 
        VALUES ( "'.$msg.'", "'.$chatId.'", "'.$username.'", "'.$current_date.'")';
        //echo $query;
        $res = $this->db->query($query);  
        return $res;
    }
    
    /**
     *  Retourne la liste des 15 dernieres commandes log 
     */
    function liste($count_max=15){
        $query = "SELECT * FROM ".$this->table_prefix."_".$this->table. " ORDER BY id DESC LIMIT 0, $count_max" ;
        $res = $this->db->query($query);
        $k = 1;
        $liste = '';
        while($row = $res->fetchArray(SQLITE3_ASSOC) ){
            $info = "- Log ".substr($row['msg'],0,30)." De: ".$row['username'].' A: '.$row['datetime'];
            $liste .= urlencode("\n".$k.$info);
            $k++;
        }        
        $liste =  utf8_encode($liste);
        return $liste;
    }
    
    /**
     *  Cette fonction retourne les stats de log
     */
     function stats(){
         //Total msg par user
         //Total msg par jour
         //Total msg par mois
         //Total msg par annee
         //Total msg par commande
     }
}
?>