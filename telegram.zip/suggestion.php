<?php

/**
 * Class Suggestion 
 * 
 * @author Samgolchi<mawusee.foli@gmail.com>
 * @copyright Copyright (c) 2017
 */
//TODO
//- Integrer Tentite :-)
//- Integrer namespace
 
//namespace Telegram;

class Suggestion
{
    /** @var db */
    public $db;
    /** @var string */
    public $type='AUTRE';
    /** @var int */
    private $chat_id;
    
    var $table_prefix = 'zbot_tg';
    var $table = 'suggestion';
    var $champs = '';

    /**
     * Suggestion constructor
     * @param db $db
     * @param $chat_id
     */
    public function __construct($db, $chat_id)
    {               
        $this->db = $db;
        $this->chat_id = intval($chat_id);        
    }

    /**
     * Retourne la liste de toutes les suggestions
     * @return bool|db_result
     */
    public function liste()
    {
        //$query = "SELECT * FROM ".$this->table_prefix."_".$this->table." WHERE type='".$this->type."'";
        $query = "SELECT * FROM ".$this->table_prefix."_".$this->table;
        //return $this->db->query($query)->fetch_all();
        $result =  $this->db->query($query);        
        $liste = "";
        $k = 1;
        while($row = $result->fetchArray(SQLITE3_ASSOC) ){
            //$liste .= urlencode("\n".$k."-".$row['auteur']."*".$row['msg']);
            $liste .= $k."-".$row['auteur']."* ".$row['msg'];
            $k++;
        }        
        $liste =  utf8_encode($liste);
        return $liste;
    }

    /**
     * Recherche les suggestions d'un lieu (quartier, ville, region)
     * @return bool|db_result
     */
    public function annuaire_Lieu($id_lieu, $type_lieu)
    {
        $query = "SELECT * FROM  ".$this->table_prefix."_".$this->table." 
        INNER JOIN 
        WHERE (type='".$this->type."')";
        return $this->db->query($query)->fetch_all();
    }

    /**
     * Recherche une suggestion a partie de son nom
     * @return string
     */
    public function recherche($nom_recherche)
    {
        $query = "SELECT * FROM  ".$this->table_prefix."_".$this->table."  WHERE (nom LIKE '%$nom_recherche%') AND (type='".$this->type."')";
		return $this->db->query($query)->fetch_all();     
    }

    /**
     * Ajouter une suggestion
     * @return string
     */
    public function ajouter($details, $separateur='**', $type='AUTRE')
    {
        $nom = $description = $quartier = '';
        $id_quartier = //TODO get id
        list($nom, $quartier, $description) = explode('**', $details);
        var_dump($nom, $quartier, $description, $type, $details);
        $query = 'INSERT INTO '.$this->table_prefix.'_'.$this->table.' (id, nom, description, type, adresse, id_quartier, id_region) 
                    VALUES (168, "'.$nom.'", "'.$description.'", "'.$this->type.'", "lomé",  "10", "2")';
                    echo $query;
		$res = $this->db->query($query);
        var_dump($res, $this->db); 
        return $res;     
    }
	
	

}