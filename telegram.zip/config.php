<?php
//DB config details
	return array(
		'database_host' => 'localhost', 
		'database_user' => 'root',
		'database_password' => '',
		'database_name' => 'lelog_bot',
		'bot_token' => 'xxx:xxx-h',//A remplacer par son propre token
		'bot_tracker' => null, 
	);
?>