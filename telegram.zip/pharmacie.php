<?php

/**
 * Class pharmacie is provided to add, get status and remove pharmacie info from mysqli database
 * 
 * @author Samgolchi<mawusee.foli@gmail.com>
 * @copyright Copyright (c) 2017
 */
/* 
namespace Telegram;

use \Structure;
*/
require_once 'structure.php';

class Pharmacie extends Structure
{
    var $type = 'PHARMACIE';
    
    /**
     * Trouve les pharmacies de garde de la semaine en cours ou de la semaine d'un jour
	 * @param string $date d'un jour format anglais 
     * @return string
     */
    public function garde($date='')
    {
        $this->table = 'garde_pharmacie';
        $date = ($date == '')?date('Y-m-d'):$date;
        $query = "SELECT nom, date_debut, date_fin, gp.id FROM  ".$this->table_prefix."_".$this->table." gp INNER JOIN ".$this->table_prefix."_structure s ON s.id=gp.id_pharmacie WHERE (date_debut <= '$date') AND (date_fin >= '$date')";

        $result = $this->db->query($query);
        /*
        $info = $result->fetchArray();
        while($row = $result->fetchArray(SQLITE3_ASSOC) ){
            var_dump($row);
        }*/
        $liste = "";
        $k = 1;
        while($row = $result->fetchArray(SQLITE3_ASSOC) ){
            $liste .= urlencode("\n".$k."- PHARMACIE ".substr($row['nom'],10));
            $k++;
        }        
        if ($liste=='') $liste = 'Aucune pharmacie programmee.';
        $liste =  utf8_encode($liste);
        return $liste;
    }		

}		