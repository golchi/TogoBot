<?php

//namespace Telegram;

class MyDB extends SQLite3
{
    // $db;
    var $table_prefix = '';
    var $table = '';
    /**
     *  Initialisation
     */
    function __construct($db_name)
    {
        $this->open($db_name);
    }   
    
}
?>